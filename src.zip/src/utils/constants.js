export const themeConst ={
    dark : 'dark',
    light : 'light'
}
