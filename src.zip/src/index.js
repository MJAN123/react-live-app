import React from 'react';
import ReactDOM from 'react-dom';
import './assets/style.scss'
import App from './app'

ReactDOM.render(
    <App/>,
    document.getElementById('root')
)
